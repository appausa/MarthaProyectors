
## Compilación en Windows con CMake

1. Instala:
   - [Visual Studio 2022+](https://visualstudio.microsoft.com/)
   - Qt 6.x para MSVC
   - CMake
   - NSIS (Nullsoft Installer)

2. Abre un terminal `x64 Native Tools for VS`.

3. Compila el proyecto:

```cmd
cd MarthaProyector
mkdir build && cd build
cmake .. -G "NMake Makefiles" -DCMAKE_PREFIX_PATH="C:/Qt/6.x.x/msvcXXXX_64"
nmake
nmake package
```

Esto generará un archivo `.msi` o `.exe` si NSIS está instalado.
