
#include "mainwindow.h"
#include <QVBoxLayout>
#include <QFileDialog>
#include <QEvent>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      cameraSelector(new QComboBox),
      startButton(new QPushButton("Iniciar Proyector")),
      stopButton(new QPushButton("Detener")),
      loadVideoBtn(new QPushButton("Cargar Video")),
      loadDocumentBtn(new QPushButton("Cargar Documento")),
      cameraDisplay(new QLabel),
      videoWidget(new QVideoWidget),
      pdfView(new QPdfView),
      mediaPlayer(new QMediaPlayer(this)),
      pdfDocument(new QPdfDocument(this)),
      proyectorStack(new QStackedWidget),
      frameTimer(new QTimer(this)),
      modoActual(ProyectorModo::Camara)
{
    QWidget *central = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(central);

    layout->addWidget(cameraSelector);
    layout->addWidget(startButton);
    layout->addWidget(stopButton);
    layout->addWidget(loadVideoBtn);
    layout->addWidget(loadDocumentBtn);

    cameraDisplay->setAlignment(Qt::AlignCenter);
    proyectorStack->addWidget(cameraDisplay);
    proyectorStack->addWidget(videoWidget);
    proyectorStack->addWidget(pdfView);
    layout->addWidget(proyectorStack);

    setCentralWidget(central);
    setMinimumSize(800, 600);

    const QList<QCameraInfo> cameras = QCameraInfo::availableCameras();
    for (const QCameraInfo &info : cameras)
        cameraSelector->addItem(info.description());

    connect(cameraSelector, QOverload<int>::of(&QComboBox::currentIndexChanged), this, &MainWindow::onCameraChanged);
    connect(startButton, &QPushButton::clicked, this, &MainWindow::startProjection);
    connect(stopButton, &QPushButton::clicked, this, &MainWindow::stopProjection);
    connect(loadVideoBtn, &QPushButton::clicked, this, &MainWindow::loadVideo);
    connect(loadDocumentBtn, &QPushButton::clicked, this, &MainWindow::loadDocument);
    connect(frameTimer, &QTimer::timeout, this, &MainWindow::updateFrame);

    mediaPlayer->setVideoOutput(videoWidget);

    if (!cameras.isEmpty()) {
        camera.open(0);
        frameTimer->start(30);
    }

    proyectorStack->setCurrentIndex(0);
}

MainWindow::~MainWindow() {
    frameTimer->stop();
    camera.close();
}

void MainWindow::onCameraChanged(int index) {
    frameTimer->stop();
    camera.close();
    if (camera.open(index)) {
        frameTimer->start(30);
    }
}

void MainWindow::updateFrame() {
    if (modoActual != ProyectorModo::Camara) return;
    QImage img = camera.getFrame();
    if (!img.isNull()) {
        cameraDisplay->setPixmap(QPixmap::fromImage(img).scaled(cameraDisplay->size(), Qt::KeepAspectRatio));
    }
}

void MainWindow::startProjection() {
    showFullScreen();
}

void MainWindow::stopProjection() {
    showNormal();
}

void MainWindow::loadVideo() {
    QString file = QFileDialog::getOpenFileName(this, "Selecciona un video", "", "Videos (*.mp4 *.avi *.mkv)");
    if (!file.isEmpty()) {
        modoActual = ProyectorModo::Video;
        proyectorStack->setCurrentIndex(1);
        mediaPlayer->setSource(QUrl::fromLocalFile(file));
        mediaPlayer->play();
        frameTimer->stop();
    }
}

void MainWindow::loadDocument() {
    QString file = QFileDialog::getOpenFileName(this, "Selecciona un documento", "", "PDF (*.pdf)");
    if (!file.isEmpty()) {
        modoActual = ProyectorModo::Documento;
        proyectorStack->setCurrentIndex(2);
        if (pdfDocument->load(file) == QPdfDocument::NoError) {
            pdfView->setDocument(pdfDocument);
            pdfView->setPage(0);
        }
        frameTimer->stop();
    }
}

void MainWindow::changeEvent(QEvent *event) {
    if (event->type() == QEvent::WindowStateChange) {
        if (isMinimized()) {
            // Se sigue proyectando incluso minimizado
        }
    }
    QMainWindow::changeEvent(event);
}
