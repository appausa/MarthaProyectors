
#!/bin/bash
APPDIR=AppDir
mkdir -p $APPDIR/usr/bin
cp ../build/MarthaProyector $APPDIR/usr/bin/
cp ../resources/marthaproyector.desktop $APPDIR/
cp ../resources/marthaproyector.png $APPDIR/
./linuxdeploy-x86_64.AppImage --appdir $APPDIR   -executable $APPDIR/usr/bin/MarthaProyector   -desktop-file $APPDIR/marthaproyector.desktop   -icon-file $APPDIR/marthaproyector.png   --output appimage
