
#ifndef CAMERA_HANDLER_H
#define CAMERA_HANDLER_H

#include <opencv2/opencv.hpp>
#include <QImage>

class CameraHandler {
public:
    bool open(int index);
    void close();
    bool isOpened() const;
    QImage getFrame();

private:
    cv::VideoCapture cap;
};

#endif // CAMERA_HANDLER_H
