
#include "camera_handler.h"

bool CameraHandler::open(int index) {
    if (cap.isOpened()) cap.release();
    return cap.open(index);
}

void CameraHandler::close() {
    if (cap.isOpened()) cap.release();
}

bool CameraHandler::isOpened() const {
    return cap.isOpened();
}

QImage CameraHandler::getFrame() {
    if (!cap.isOpened()) return QImage();

    cv::Mat frame;
    cap >> frame;

    if (frame.empty()) return QImage();

    cv::cvtColor(frame, frame, cv::COLOR_BGR2RGB);
    return QImage(frame.data, frame.cols, frame.rows, frame.step, QImage::Format_RGB888).copy();
}
