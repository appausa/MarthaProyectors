# MarthaProyector

Proyector de cámara, documentos PDF y videos multiplataforma escrito en C++ y Qt6.