
# MarthaProyector

**MarthaProyector** es una aplicación multiplataforma escrita en C++ y Qt6 que permite utilizar la cámara delantera o trasera como proyector, así como mostrar archivos de video o documentos PDF. Compatible con Linux, AppImage y Android.

---

## Requisitos

### Linux (Debian 12 o similar)
```bash
sudo apt update
sudo apt install build-essential cmake qt6-base-dev qt6-multimedia-dev qt6-tools-dev-tools libopencv-dev libpoppler-qt6-dev
```

---

## Compilación en Linux

```bash
cd MarthaProyector
mkdir build && cd build
cmake ..
make -j$(nproc)
./MarthaProyector
```

---

## Crear AppImage

1. Descarga `linuxdeploy`:
```bash
wget https://github.com/AppImage/AppImageKit/releases/download/continuous/linuxdeploy-x86_64.AppImage
chmod +x linuxdeploy-x86_64.AppImage
```

2. Ejecuta el script:
```bash
cd MarthaProyector/scripts
./build_appimage.sh
```

Esto generará un archivo `.AppImage` portable.

---

## Compilar para Android (APK)

### Requisitos

- Qt 6.x con soporte para Android
- Android SDK
- Android NDK
- Java JDK (>=11)
- Gradle

### Pasos

1. Abre Qt Creator
2. Ve a **Herramientas > Opciones > Kits > Android**
3. Configura el SDK/NDK/JDK correctos
4. Carga el proyecto `MarthaProyector`
5. Selecciona el kit `Android (arm64-v8a)`
6. Compila y genera el `.apk`

**Permisos utilizados en Android:**
- Cámara (`android.permission.CAMERA`)
- Almacenamiento (`android.permission.READ_EXTERNAL_STORAGE`)

---

## Características

- Modo cámara (selección frontal o trasera)
- Modo proyector de video (mp4, mkv, avi)
- Modo documento (PDF)
- Minimizable mientras proyecta

---

## Créditos

Desarrollado con Qt6, OpenCV y Poppler.

---

## Licencia

MIT (o la que desees definir)

