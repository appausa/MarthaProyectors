
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QComboBox>
#include <QLabel>
#include <QTimer>
#include <QMediaPlayer>
#include <QVideoWidget>
#include <QPdfDocument>
#include <QPdfView>
#include <QStackedWidget>
#include "camera_handler.h"

enum class ProyectorModo {
    Camara,
    Video,
    Documento
};

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onCameraChanged(int index);
    void updateFrame();
    void startProjection();
    void stopProjection();
    void loadVideo();
    void loadDocument();

protected:
    void changeEvent(QEvent *event) override;

private:
    QComboBox *cameraSelector;
    QPushButton *startButton;
    QPushButton *stopButton;
    QPushButton *loadVideoBtn;
    QPushButton *loadDocumentBtn;

    QLabel *cameraDisplay;
    QStackedWidget *proyectorStack;
    QVideoWidget *videoWidget;
    QPdfView *pdfView;

    QMediaPlayer *mediaPlayer;
    QPdfDocument *pdfDocument;

    QTimer *frameTimer;
    CameraHandler camera;
    ProyectorModo modoActual;
};

#endif // MAINWINDOW_H
